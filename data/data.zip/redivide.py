import pickle as pkl
import numpy as np
import time



np.random.seed(int(time.time()))
datasets = ["DBLP", "IMDB", "ACM"]
proportion = [0.2, 0.4, 0.6, 0.8]
for dataset in datasets:
    label_path = dataset + "/labels.pkl"
    with open(label_path, 'rb') as f:
        labels = pkl.load(f)
    all_list = np.vstack(labels)
    for p in proportion:
        result = []
        np.random.shuffle(all_list)
        all_train_nodes = int(all_list.shape[0]*p)
        train_nodes = int(all_train_nodes*0.8)
        result.append(all_list[0:train_nodes,:])
        result.append(all_list[train_nodes:all_train_nodes,:])
        result.append(all_list[all_train_nodes:-1, :])
        print(result)
        with open(dataset + "/labels_"+str(int(p*100))+".pkl", "wb") as out:
            pkl.dump(result,out)




