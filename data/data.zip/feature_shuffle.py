import pickle
import numpy as np

datasets = ["DBLP", "ACM", "IMDB"]

for dataset in datasets:
    with open(dataset+"/node_features.pkl","rb") as f:
        features = pickle.load(f)
    with open(dataset+"/node_type","rb") as f:
        node_type = pickle.load(f)

    type_dict = {}
    for node in node_type:
        if node_type[node] not in type_dict:
            type_dict[node_type[node]]=[]
        type_dict[node_type[node]].append(node)
    feature_dim = features.shape[1]
    new_features = np.zeros_like(features)
    for type in type_dict:
        order = np.array(list(range(feature_dim)))
        np.random.shuffle(order)
        for i in range(features.shape[1]):
            new_features[type_dict[type],i]=features[type_dict[type],order[i]]

    with open(dataset+"/shuffled_features.pkl","wb") as f:
        pickle.dump(new_features,f)